-- 
-- Editor SQL for DB table datauno
-- Created by http://editor.datatables.net/generator
-- 

CREATE TABLE IF NOT EXISTS `datauno` (
	`id` int(10) NOT NULL auto_increment,
	`titulo` varchar(255),
	`dato` varchar(255),
	`sesion` varchar(255),
	PRIMARY KEY( `id` )
);