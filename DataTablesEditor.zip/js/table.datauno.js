
/*
 * Editor client script for DB table datauno
 * Created by http://editor.datatables.net/generator
 */

addEventListener("DOMContentLoaded", function () {
	var editor = new DataTable.Editor( {
		ajax: 'php/table.datauno.php',
		table: '#datauno',
		fields: [
			{
				"label": "titulo:",
				"name": "titulo"
			},
			{
				"label": "dato:",
				"name": "dato"
			},
			{
				"label": "sesion:",
				"name": "sesion"
			}
		]
	} );

	var table = new DataTable('#datauno', {
		ajax: 'php/table.datauno.php',
		columns: [
			{
				"data": "titulo"
			},
			{
				"data": "dato"
			},
			{
				"data": "sesion"
			}
		],
		layout: {
			topStart: {
				buttons: [
					{ extend: 'create', editor: editor },
					{ extend: 'edit', editor: editor },
					{ extend: 'remove', editor: editor }
				]
			}
		},
		select: true
	});
});

