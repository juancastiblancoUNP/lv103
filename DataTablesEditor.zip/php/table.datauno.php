<?php

/*
 * Editor server script for DB table datauno
 * Created by http://editor.datatables.net/generator
 */

// DataTables PHP library and database connection
include( "lib/DataTables.php" );

// Alias Editor classes so they are easy to use
use
	DataTables\Editor,
	DataTables\Editor\Field,
	DataTables\Editor\Format,
	DataTables\Editor\Mjoin,
	DataTables\Editor\Options,
	DataTables\Editor\Upload,
	DataTables\Editor\Validate,
	DataTables\Editor\ValidateOptions;

// The following statement can be removed after the first run (i.e. the database
// table has been created). It is a good idea to do this to help improve
// performance.
$db->sql( "CREATE TABLE IF NOT EXISTS `datauno` (
	`id` int(10) NOT NULL auto_increment,
	`titulo` varchar(255),
	`dato` varchar(255),
	`sesion` varchar(255),
	PRIMARY KEY( `id` )
);" );

// Build our Editor instance and process the data coming from _POST
Editor::inst( $db, 'datauno', 'id' )
	->fields(
		Field::inst( 'titulo' ),
		Field::inst( 'dato' ),
		Field::inst( 'sesion' )
	)
	->process( $_POST )
	->json();
